let scene;
let layer;

function Init() {
    Fortis.Game.config.debug = true;
    //Fortis.Game.canvasCfg.keepAspect = false;
    Fortis.FontLoader.addFonts({
        "test": 'https://fonts.googleapis.com/css2?family=RocknRoll+One&display=swap',
    });
    Fortis.ImageLoader.addImages({
        "sample": "./sample.jpg",
        "ss": "./spritesheet.png",
    });

    Fortis.SoundLoader.addSimpleSounds({
        "dededon": "./get.mp3",
        "star": "./maou_14_shining_star.mp3",
    });

    Fortis.SoundLoader.addNormalSounds({
        //"star":"./maou_14_shining_star.mp3",
        "dededon": "./get.mp3",
    })
}

let colg,colR;
let colG,colL;

let testL;
let testR;
function Ready() {
    colg = new Fortis.ColliderGroup();
    colG = new Fortis.ColliderGroup();
    colR = new Fortis.RectCollider();
    colL = new Fortis.LineCollider();
    
    colg.addList([colR]);
    colG.addList([colL]);

    layer = new Fortis.Layer();
    

    testL = new Fortis.Entity(new Fortis.LineShape(),new Fortis.ColorMaterial(null,new Fortis.Color("blue")));
    layer.add(testL);
    colG.link(testL)

    testR = new Fortis.Entity(new Fortis.RectShape(),new Fortis.ColorMaterial(new Fortis.Color("blue")));
    layer.add(testR);
    colg.link(testR);
    testR.pos = new Fortis.Vector2(100,100);

    scene = new Fortis.Scene();
    scene.add(layer);
    Fortis.Game.setScene(scene);
}


function Update(delta) {
    colG.update();
    colg.update();

    console.log(colR.getVertices())
    console.log(Fortis.util.checkPolygonsCollide(colL.getVertices(),colR.getVertices()))
    //console.log(colG.pos)
testL.pos = Fortis.Game.mouse.pos;
}

function EngineLoaded() { }

function Test(delta) {
    /*
    for(let i = 1; i<7; i++){
        rects[i].pos = new Fortis.Vector2(Math.random()*500,Math.random()*200);
    }
    */
    //console.log(delta)
    //sse.shape.stop();
    //sse.shape.backFrame();
    //console.log("konnitiha");
}